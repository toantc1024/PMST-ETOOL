

import React, { Component } from 'react';
import { StyleSheet, css } from 'aphrodite';
import Button from '@material-ui/core/Button';

import { getHighScore } from '../config/SaveScore';

const styles = StyleSheet.create({
    container: {
        display: 'flex',
        flex: 1,
        flexDirection: 'column',
        textAlign: 'center',
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default class About extends Component {

    render() {

        return (
            <div className={css(styles.container)}>
                <h3>{`Điểm số : ${this.props.score}`}</h3>
                <h3>{`Điểm số cao nhất: ${getHighScore()}`}</h3>

                <h4>Hướng dẫn cách chơi</h4>
                <div>Tạo ra từ tiếng Anh với chữ các chữ cái</div>
                <div>
Chọn các chữ cái bằng cách click chuột và sau đó ấn nút 'Phá hủy' (thả chuột khoảng 2 giây để chương trình kiểm tra xong), nếu như từ vựa chọn hợp lệ thì các chữ cái đã chọn sẽ biến mất</div>
                <Button href="https://www.youtube.com/watch?v=Txa8OehxL30">
                    Video chơi thử
                </Button>
            </div>
        );
    }
}




