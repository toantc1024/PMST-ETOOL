# WordTetris
Cài đặt bộ phận của Nodejs chạy lên `npm install` (cd vào đường dẫn trên cmd) để cài node_modules
Để chaỵ phần mềm `npm start`
