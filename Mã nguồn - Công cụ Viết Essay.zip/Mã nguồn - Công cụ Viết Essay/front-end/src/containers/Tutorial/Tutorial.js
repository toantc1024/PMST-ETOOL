import React, { useState, useEffect } from 'react';
import classes from './Tutorial.module.css';
import { connect } from 'react-redux';
import * as actionTypes from '../../store/actions/actionTypes';

// Material UI
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import CloseRoundedIcon from '@material-ui/icons/CloseRounded';

// Images
import img1 from '../../images/FindSyno1.png';
import img2 from '../../images/FindSyno2.png';
import img3 from '../../images/FindSyno3.png';
import img4 from '../../images/FindSyno4.png';
import img5 from '../../images/FindSyno5.png';

const Tutorial = props => {
    const [stage, setStage] = useState(0);

    useEffect(() => {
        if (props.tutorialModalOpen) {
            setStage(0);
        }
    }, [props.tutorialModalOpen]);

    const nextButtonClickedHandler = () => {
        if (stage < 4) {
            setStage(stage + 1);
        }
    }

    const backButtonClickedHandler = () => {
        if (stage !== 0) {
            setStage(stage - 1);
        }
    }

    const imageStyle = {
        width: '100%'
    }
    
    const content = [
        {
            image: <span className={classes.ImageBox}><img src={img1} style={imageStyle}/></span>,
            description: 'Khi bạn gần hoàn thành bài viết, dán bài viết của bạn vào đây.'
        },
        {
            image: <div className={classes.ImageBox}><img src={img2} style={imageStyle}/></div>,
            description: `Nhấp vào KIỂM TRA, phần mềm sẽ tìm kiếm qua bài viết của bạn và tìm ra các từ sử dụng nhiều.`
        },
        {
            image: <span className={classes.ImageBox}><img src={img3} style={imageStyle}/></span>,
            description: 'Các từ được tìm thấy sẽ được liệt kê theo thứ tự. Nhấp vào một từ nào đó để xem từ đồng nghĩa.'
        },
        {
            image: <div className={classes.ImageBox}><img src={img4} style={imageStyle}/></div>,
            description: `Các từ đồng nghĩa của từ sẽ xuất hiện và tất cả các trường hợp sẽ được đánh dấu.`
        },
        {
            image: <span className={classes.ImageBox}><img src={img5} style={imageStyle}/></span>,
            description: `Bạn có thể chọn bỏ qua một từ nếu bạn không thấy nó đặc biệt hữu ích (không cần thiết).`
        },
    ]

    return <Dialog
    scroll={'paper'}
    fullWidth={true}
    open={props.tutorialModalOpen}
    onClose={props.onToggleModal}
    style={{overflowY: 'scroll'}}
    >
        <CloseRoundedIcon onClick={props.onToggleModal} className={classes.CloseIcon}/>
        <DialogTitle style={{backgroundColor: '#DFE6EC', textAlign: 'center'}}>{"Hướng dẫn sử dụng Find Synonym"}</DialogTitle>

        <DialogContent
        style={{backgroundColor: '#DFE6EC'}}
        >
            {content[stage].image}

            <DialogContentText id="alert-dialog-description" style={{marginTop: '30px'}}>
                {content[stage].description}
            </DialogContentText>

        </DialogContent>


        <DialogActions style={{backgroundColor: '#DFE6EC'}}>

        <button 
        onClick={backButtonClickedHandler}
        disabled={stage === 0}
        className={classes.Button}
        >
            Trước đó
        </button>

        <button 
        onClick={nextButtonClickedHandler}
        disabled={stage === content.length - 1}
        className={classes.Button}
        >
            Kế tiếp
        </button>
        </DialogActions>


  </Dialog>
}

const mapStateToProps = state => {
    return {
        tutorialModalOpen: state.tutorial.modal,
        pallete: state.pallete.pallete
    }
}

const mapDispatchToProps = dispatch => {
    return {
        onToggleModal: () => dispatch({type: actionTypes.TOGGLE_TUTORIAL_MODAL})
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Tutorial)
