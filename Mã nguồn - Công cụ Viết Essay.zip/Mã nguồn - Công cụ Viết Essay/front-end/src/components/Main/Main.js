import React from 'react';
import classes from './Main.module.css';
import { connect } from 'react-redux';

const main = props => {
    return <div className={classes.Main} 
    style={{backgroundColor: props.pallete.backgroundMain}}>
        
        <h3 className={classes.Header}
        style={{
            color: props.pallete.accentText
        }}>Phần mềm tìm thấy các từ được sử dụng nhiều trong bài viết của bạn và đề xuất các lựa chọn thay thế.</h3>
        
        {props.children}
    </div>
}

const mapStateToProps = state => {
    return {
        pallete: state.pallete.pallete
    }
}

export default connect(mapStateToProps)(main);