import React from 'react';
import classes from './About.module.css';
import { connect } from 'react-redux';

function About(props) {
    const neuBorder = props.darkMode ? {
        boxShadow: 'inset 4px 4px 10px rgba(0, 0, 0, 0.18), inset -4px -4px 10px rgba(255, 255, 255, 0.015)'
    }
    : {
        boxShadow: 'inset 3px 3px 6px rgba(0, 0, 0, 0.08), inset -3px -3px 6px rgba(255, 255, 255, 0.5)'
    }

    return <div id="about" className={classes.About}
    style={{
        color: props.pallete.userInputText,
        backgroundColor: props.pallete.backgroundMain
    }}>
        <div className={classes.AboutBox}
        style={{
            ...neuBorder
        }}>
            <div className={classes.Section}>
                <h1 className={classes.MainHeader}>Phần mềm dùng để làm gì?</h1>
                <p className={classes.SecondaryHeader}>Giúp giảm bớt sự lặp từ trong bài viết (Essay) của bạn.</p>
                <p className={classes.Text}>
                    Phần mềm đọc qua bài viết của bạn và tìm các từ lặp lại, 
                    sau đó so sánh việc sử dụng các từ với sự xuất hiện ước tính của chúng bằng ngôn ngữ hàng ngày, 
                    xếp hạng thứ tự chúng dựa trên tần suất và gợi ý từ đồng nghĩa.
                </p>
            </div>
            
            <div className={classes.Section}>
                <h1 className={classes.MainHeader}>Phần mềm hoạt động như thế nào? </h1>
                <p className={classes.Text}>
                    Sau khi quét qua tạo ra danh sách từ xuất hiện hơn hai lần,
                    Phần mềm tìm kiếm từ này trong danh sách 97.565 từ duy nhất được sử dụng ở hơn 743 tỷ nơi khác nhau được xếp hạng từ hầu hết đến ít được sử dụng nhất
                    được thu thập bởi <a target="_blank" href="http://norvig.com/mayzner.html" style={{color: props.pallete.userInputText}}>Peter Norvig</a> từ dữ liệu do Google Books cung cấp.
                </p>
                <p className={classes.Text}>
                    Bởi vì việc sử dụng từ Tiếng Anh tuân theo luật <a target="_blank" href="https://en.wikipedia.org/wiki/Zipf%27s_law" style={{color: props.pallete.userInputText}}> phân phối Zipf</a>,  
                    phần mềm có thể sử dụng các từ trong danh sách này để đưa ra một ước tính chính xác về tần suất của nó (số liệu dùng hằng ngày).
                    Sau đó, phần mềm so sánh sự xuất hiện trong bài viết của bạn với sự xuất hiện trung bình để đưa ra kết quả hợp lý.
                    Việc làm này được sử dụng như một chuẩn mực chung cho mức độ dùng quá nhiều từ (lạm dụng từ).
                    Cuối cùng, phần mềm lấy những từ được sử dụng quá nhiều nhất và thu thập tất cả các từ đồng nghĩa có thể tìm thấy trong dữ liệu và cung cấp chúng cho bạn.
                </p>
            </div>

            <div id="tutorial" className={classes.Section}>
                <h1 className={classes.MainHeader}>Sử dụng phần mềm như thế nào?</h1>
                <p className={classes.Text}>
                    Khi bạn cảm thấy gần hoàn thành bản nháp (hơn 200 từ), dán bài viết của bạn vào trường văn bản và nhấp vào nút KIỂM TRA.
                    Sau khi xử lý hoàn tất, phần mềm sẽ liệt kê những từ tìm thấy khả năng dùng nhiều nhất ở thanh bên trái.
                </p>

                <p className={classes.Text}>
                    Để tìm các từ đồng nghĩa của từ cụ thể, nhấp chuột vào từ đó trên thanh bên trái.
                    Tất cả các từ đồng nghĩa phần mềm có thể tìm thấy sẽ được hiển thị ở đầu màn hình và tất cả các trường hợp của từ đó sẽ được đánh dấu.
                </p>
                
            </div>
            
        </div>
    </div>
}

const mapStateToProps = state => {
    return {
        pallete: state.pallete.pallete,
        darkMode: state.pallete.darkMode
    }
}

export default connect(mapStateToProps)(About);


