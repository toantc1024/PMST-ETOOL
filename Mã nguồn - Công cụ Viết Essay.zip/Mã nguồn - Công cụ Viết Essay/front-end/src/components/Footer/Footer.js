import React from 'react';
import { connect } from 'react-redux';
import classes from './Footer.module.css';
import GitHubIcon from '@material-ui/icons/GitHub';
import LinkedInIcon from '@material-ui/icons/LinkedIn';
import MailOutlineIcon from '@material-ui/icons/MailOutline';

const Footer = props => {
    return <div 
    className={classes.Footer}
    style={{color: props.pallete.navbarText}}
    >
        <div className={classes.DarkModeBackdrop} style={props.darkMode ? {opacity: '1'} : {}}></div>
        <div className={classes.InfoBox}>
            <h3 className={classes.NameYear}>Find Synonym - Công Cụ Viết Essay {new Date().getFullYear()}</h3>
            <div className={classes.Icons}>
            </div>
        </div>
        
    </div>
}

const mapStateToProps = state => {
    return {
        pallete: state.pallete.pallete,
        darkMode: state.pallete.darkMode
    }
}

export default connect(mapStateToProps)(Footer)