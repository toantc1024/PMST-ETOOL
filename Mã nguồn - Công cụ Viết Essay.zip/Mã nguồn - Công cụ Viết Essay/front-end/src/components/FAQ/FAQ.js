import React, { useEffect } from 'react';
import classes from './FAQ.module.css';
import { connect } from 'react-redux';

function FAQ(props) {

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);
    const neuBorder = props.darkMode ? {
        boxShadow: 'inset 4px 4px 10px rgba(0, 0, 0, 0.18), inset -4px -4px 10px rgba(255, 255, 255, 0.015)'
    }
    : {
        boxShadow: 'inset 3px 3px 6px rgba(0, 0, 0, 0.08), inset -3px -3px 6px rgba(255, 255, 255, 0.5)'
    }
    return <div className={classes.FAQ}
    style={{backgroundColor: props.pallete.backgroundMain, color: props.pallete.userInputText}}>
        <h1 className={classes.MainHeader}>Các câu hỏi thường gặp</h1>

        <div className={classes.MainBox} style={neuBorder}>

            <div className={classes.Section}>
                <h2 className={classes.Question}>Phần mềm xử lý được ngôn ngữ nào?</h2>
                <p className={classes.Answer}>Hiện tại, phần mềm hỗ trợ xử lý văn bản thuộc ngôn ngữ <bold> Tiếng Anh - Mỹ</bold>. Các ngôn ngữ khác có thể được kiểm tra; Tuy nhiên, điều này có thể dẫn đến một số từ không thể tìm kiếm chính xác hoặc bị bỏ qua.</p>
            </div>

            <div className={classes.Section}>
                <h2 className={classes.Question}>Phần mềm có thể kiểm tra chính tả không?</h2>
                <p className={classes.Answer}>Không. Phần mềm sẽ được sử dụng như công cụ phân bố tần suất và đưa ra gợi ý từ đồng nghĩa thay thế thích hợp. Việc này có nghĩa là việc kiểm tra ngữ pháp và chỉnh sửa văn phong nên được thực hiện trước. Phần mềm sẽ hữu ích nhất cho bạn trước khi nộp bài luận (Essay).</p>
            </div>

            <div className={classes.Section}>
                <h2 className={classes.Question}>Tại sao đoạn văn bản phải tối thiểu 200 từ?</h2>
                <p className={classes.Answer}>Kích thước 200 từ là hợp lý. Nếu như đoạn văn dưới 200 từ gây ra kết quả không phù hợp trong tìm kiếm (Tìm từ đồng nghĩa). Từ đó phần mềm trở nên khó hiểu hơn là hữu ích.</p>
            </div>

            <div className={classes.Section}>
                <h2 className={classes.Question}>Tại sao phần mềm lại hiểu sai một số từ?</h2>
                <p className={classes.Answer}>Hiện tại, phần mềm không thể kiểm tra theo ngữ cảnh. Nếu các từ đồng nghĩa cụ thể (Tình thái, Cảm xúc, ...), bạn có thể nhấp vào <bold> BỎ QUA </bold> để không hiện thị lại (cho đến khi khởi động lại phần mềm)</p>
            </div>


        </div>
    </div>
}


const mapStateToProps = state => {
    return {
        pallete: state.pallete.pallete,
        darkMode: state.pallete.darkMode
    }
}

export default connect(mapStateToProps)(FAQ);
