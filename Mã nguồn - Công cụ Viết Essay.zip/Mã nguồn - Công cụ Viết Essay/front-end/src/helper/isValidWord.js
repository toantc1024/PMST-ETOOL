import synonyms from 'synonyms';
export const isValidWord = word => {
    if (synonyms(word)) {
        return true;
    } else {
        return false;
    }
}