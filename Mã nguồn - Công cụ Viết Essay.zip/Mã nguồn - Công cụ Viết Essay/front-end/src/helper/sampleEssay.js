// Bài luận mẫu
const essays = [

    `Nowadays, English has become very popular language around the world. There are more than 700 million English users in the world which is a terrible number to prove the importance of English. In this essay, I will discuss about the necessity of learning English.

    According to the recent research conducted in America last January of this year: 103% of the travelers is good at speaking English. This means that people use English to communicate everyone is very popular, so this language widespread everywhere, especially in the rural areas. Students is in the countryside who have learned English since they were in primary school. Besides, many language centers are opened to serve our learning.
    
    English is a useful language for us. Firstly, Learning English helps people communicate and travel easily. Especially, it helps people in many different countries work together. Secondly, it is a good opportunity for our career. We can communicate with international customers and partners without language barriers to get more opportunities. Thirdly, English is the main language of newspapers and books. In our work, it helps us understand documents relating to our job. Furthermore, we have a good job and high salary in the future which have a change of studying aboard.
    
    Today, Learning English becomes easy with everything around our life. We can study with Internet which we chat with foreign friends and find information. We can also walk the park and exchange with foreign travelers.
    
    To sum up, Learning English is very important with us which helps us to attend good results in the working. We must try to learn good English because it is one the most difficult language.`
]

export default function getSampleEssay() {
    return essays[Math.floor(Math.random() * essays.length)];
}